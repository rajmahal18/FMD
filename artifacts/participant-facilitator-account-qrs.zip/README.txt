Account access QR codes
Open print.html to print all labels at 100% scale, or use individual PNG/SVG files on participant IDs. Keep the white quiet zone.
These URLs identify accounts; a password is still required. No attendance or scoring is recorded.
The /players/[code] implementation must be deployed to https://fmd-three.vercel.app before scanning will work. Account IDs must be preserved when updating the roster.
